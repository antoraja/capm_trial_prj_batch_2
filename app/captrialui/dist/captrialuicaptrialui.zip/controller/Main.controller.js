sap.ui.define(["sap/ui/core/mvc/Controller"],function(i){"use strict";return i.extend("captrialui.captrialui.controller.Main",{onInit:function(){}})});
//# sourceMappingURL=Main.controller.js.map